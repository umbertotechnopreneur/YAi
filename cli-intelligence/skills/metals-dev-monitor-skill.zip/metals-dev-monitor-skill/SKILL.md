---
name: metals-dev-monitor
description: Query Metals.Dev for metals and FX data, convert amounts, and list supported symbols
version: 1.1.0
metadata:
  openclaw:
    os: [win32, darwin, linux]
    requires:
      bins: [pwsh]
    emoji: 🪙
    homepage: https://metals.dev/docs
---

# Metals.Dev Monitor Skill

Query Metals.Dev for metals and FX data.

## Actions

- **run**: Query Metals.Dev and generate a comparison report plus history files.
- **convert**: Convert an amount from one currency or metal code to another.
- **list_symbols**: Return the list of supported currencies, metals, and units.

## Usage

```text
[TOOL: metals-dev-monitor action=run api_key="YOUR_API_KEY"]
[TOOL: metals-dev-monitor action=convert api_key="YOUR_API_KEY" from_code="EUR" to_code="VND" amount="100"]
[TOOL: metals-dev-monitor action=convert api_key="YOUR_API_KEY" from_code="gold" to_code="USD" amount="2" unit="toz"]
[TOOL: metals-dev-monitor action=list_symbols api_key="YOUR_API_KEY"]
```

## Parameters

### Common

- **action** (required): `run`, `convert`, or `list_symbols`.
- **api_key** (required): Your Metals.Dev API key.
- **timeout_seconds** (optional): HTTP timeout in seconds. Default: `30`.

### Run action

- **output_folder** (optional): Destination folder for report and history files. Default: `./metals-dev-output`.
- **currency_base** (optional): Base currency for the report. Default: `USD`.
- **metal_unit** (optional): Metal unit for the report. Default: `toz`.
- **fx_pairs** (optional): Comma-separated FX pairs to report. Default: `EUR/USD,USD/VND,EUR/VND`.
- **append_history** (optional): `true` to append CSV history, `false` to skip. Default: `true`.

### Convert action

- **from_code** (required): Source code such as `EUR`, `USD`, `VND`, `gold`, `silver`, `platinum`, `palladium`.
- **to_code** (required): Target code such as `EUR`, `USD`, `VND`, `gold`, `silver`, `platinum`, `palladium`.
- **amount** (required): Amount to convert.
- **currency** (optional): Quote currency used when querying latest metals data. Default: `USD`.
- **unit** (optional): Metal unit used when querying latest metals data. Default: `toz`.

### List symbols action

- **include_currencies** (optional): `true` to include currencies. Default: `true`.
- **include_metals** (optional): `true` to include metals. Default: `true`.
- **include_units** (optional): `true` to include units. Default: `true`.

## Output

### Run

Writes:
- `latest-report.md`
- `latest-snapshot.json`
- `history-metals.csv`
- `history-fx.csv`

### Convert

Writes no files. Returns a structured text result with source, target, amount, rate, and converted value.

### List symbols

Writes no files. Returns a readable list of supported metals, currencies, and units.

## Safety

This skill:
- calls the public Metals.Dev API over HTTPS
- writes files only for the `run` action and only under the selected output folder
- does not delete files
- does not store the API key in output files
- returns an error if the API response is invalid or indicates failure

## Notes

The implementation uses:
- `https://api.metals.dev/v1/latest` for metals and live conversion context
- `https://api.metals.dev/v1/currencies` for live currency rates

Supported metals and currencies are based on the Metals.Dev documentation.
