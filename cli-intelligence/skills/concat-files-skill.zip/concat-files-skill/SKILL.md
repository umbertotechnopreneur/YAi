---
name: concat-files
description: Concatenate matching source files from a folder tree into grouped UTF-8 text chunks
version: 1.0.0
metadata:
  openclaw:
    os: [win32, darwin, linux]
    requires:
      bins: [pwsh]
    primaryEnv: PWD
    emoji: 📦
---

# Concat Files Skill

Concatenate matching source files from a folder tree into grouped UTF-8 text output files.

## Actions

- **run**: Scan a folder recursively, filter files by extension, skip ignored folders/files, and write grouped output files.

## Usage

```text
[TOOL: concat-files_run InputFolder="C:\\repos\\my-project"]
[TOOL: concat-files_run InputFolder="C:\\repos\\my-project" OutputFolder="C:\\temp\\concat-out" GeneratedFileCharLimit="450000"]
[TOOL: concat-files_run InputFolder="C:\\repos\\my-project" AllowedExtensions=".cs,.md,.json" IgnoredFolders="bin,obj,node_modules,.git"]
```

## Parameters

- **InputFolder** (required): Root folder to scan recursively.
- **OutputFolder** (optional): Folder where concatenated output will be written. Default: `<InputFolder>/concatenated-output`.
- **GeneratedFileCharLimit** (optional): Maximum approximate character length for each generated file. Must be greater than 0. Default: `450000`.
- **AllowedExtensions** (optional): Comma-separated list of file extensions to include. Default: `.cs,.vue,.js,.md,.txt,.json,.html,.ts,.c,.cpp,.h`.
- **IgnoredFolders** (optional): Comma-separated list of folder names to skip recursively. Default: `dist,bin,obj,.git,.vs,.github,.vscode,node_modules`.
- **IgnoredFiles** (optional): Comma-separated list of file names to skip. Default: `package-lock.json,yarn.lock`.
- **SkipOutputFolderWhenInsideInput** (optional): If `true`, the script avoids re-reading files already generated in the output folder when the output folder is inside the input root. Default: `true`.
- **MaxIndividualFileSizeBytes** (optional): Skip files larger than this size in bytes. Default: `5242880`.

## Output

The script writes UTF-8 `.txt` files grouped by extension under the output folder. Each generated file contains per-file headers, metadata, and raw content.

## Safety

This skill is **not read-only**.

It will:
- read files recursively under `InputFolder`
- create directories under `OutputFolder` if needed
- write UTF-8 text files to `OutputFolder`

It will **not**:
- delete source files
- modify source files
- overwrite files outside the chosen output folder

Notes:
- Generated output can contain sensitive source code or text if the input folder contains them.
- The script skips files above the configured max size to avoid accidental huge outputs.
- If the output folder is placed inside the input folder, the script can automatically exclude it from scanning.
