# Metals.Dev Monitor Skill Plan

## Goal

Create an importable CLI-Intelligence skill that queries Metals.Dev for:
- gold
- silver
- EUR/USD
- USD/VND
- EUR/VND

and then writes:
- a human-readable Markdown report
- a JSON snapshot
- CSV history files for later comparison

## Chosen Provider

**Metals.Dev**

Reason:
- one provider for metals and FX
- simple HTTPS JSON API
- documented `latest` endpoint for metals
- documented `currencies` endpoint for FX
- suitable for low-frequency personal tracking

## Deliverables

1. `SKILL.md`
2. `scripts/run.ps1`
3. `README.md`
4. ZIP package ready to import into CLI-Intelligence

## Script Responsibilities

The PowerShell script will:
1. validate input parameters
2. call Metals.Dev
3. normalize gold and silver prices
4. normalize FX rates
5. derive cross-rate calculations
6. append CSV history
7. emit a Markdown summary

## Comparison Logic

The report will show:
- current gold price
- current silver price
- current EUR/USD
- current USD/VND
- current EUR/VND
- day-over-day comparison when previous rows exist locally

## Storage Layout

```text
metals-dev-output/
├── latest-report.md
├── latest-snapshot.json
├── history-metals.csv
└── history-fx.csv
```

## Safety

- no deletion
- no overwrite outside selected output folder
- no secret persistence
- clear failures on invalid API responses
