# Concat Files Skill Package

This archive contains a ready-to-drop CLI-Intelligence skill package:

- `SKILL.md`
- `scripts/run.ps1`

Suggested target location:

- `storage/skills/concat-files/`
- or `data/skills/concat-files/`

Notes:

- The executable tool name exposed by the current script-skill auto-registration logic will be based on the skill name and script file name, so `run.ps1` becomes `concat-files_run`.
- The script keeps the original behavior you shared, but adds a few hardening improvements:
  - validates positive limits
  - supports comma-separated list parameters
  - avoids re-reading generated output when the output folder is inside the input root
  - skips files above a configurable max size
  - documents side effects explicitly
