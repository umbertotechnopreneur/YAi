# Metals.Dev Monitor Skill

This skill package for CLI-Intelligence uses Metals.Dev to:

- generate a metals and FX report with local CSV history
- convert an amount from one code to another
- list supported currencies, metals, and units

## Actions

### run

Example:

```powershell
[TOOL: metals-dev-monitor action=run api_key="YOUR_API_KEY"]
```

### convert

Examples:

```powershell
[TOOL: metals-dev-monitor action=convert api_key="YOUR_API_KEY" from_code="EUR" to_code="VND" amount="100"]
[TOOL: metals-dev-monitor action=convert api_key="YOUR_API_KEY" from_code="gold" to_code="USD" amount="1" unit="toz" currency="USD"]
```

### list_symbols

Example:

```powershell
[TOOL: metals-dev-monitor action=list_symbols api_key="YOUR_API_KEY"]
```

## Notes

- `convert` resolves currencies from the `currencies` endpoint and metals from the `latest` endpoint.
- metal conversions are contextual to the selected quote `currency` and `unit`.
- `list_symbols` uses a built-in metals/units list aligned to Metals.Dev documentation and fetches current currencies from the API.
