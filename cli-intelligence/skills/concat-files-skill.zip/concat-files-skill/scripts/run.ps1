[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$InputFolder,

    [Parameter()]
    [string]$OutputFolder = (Join-Path -Path $InputFolder -ChildPath 'concatenated-output'),

    [Parameter()]
    [ValidateRange(1, [int]::MaxValue)]
    [int]$GeneratedFileCharLimit = 450000,

    [Parameter()]
    [string[]]$AllowedExtensions = @('.cs', '.vue', '.js', '.md', '.txt', '.json', '.html', '.ts', '.c', '.cpp', '.h'),

    [Parameter()]
    [string[]]$IgnoredFolders = @('dist', 'bin', 'obj', '.git', '.vs', '.github', '.vscode', 'node_modules'),

    [Parameter()]
    [string[]]$IgnoredFiles = @('package-lock.json', 'yarn.lock'),

    [Parameter()]
    [bool]$SkipOutputFolderWhenInsideInput = $true,

    [Parameter()]
    [ValidateRange(1, [long]::MaxValue)]
    [long]$MaxIndividualFileSizeBytes = 5242880
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Normalize-Path {
    param([Parameter(Mandatory = $true)][string]$Path)

    return [System.IO.Path]::GetFullPath($Path.Trim())
}

function Normalize-Extension {
    param([Parameter(Mandatory = $true)][string]$Extension)

    $value = $Extension.Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw 'Extension values cannot be empty.'
    }

    if ($value.StartsWith('.')) {
        return $value
    }

    return ".${value}"
}

function Split-ListParameter {
    param([object[]]$Values)

    $list = [System.Collections.Generic.List[string]]::new()
    foreach ($value in @($Values)) {
        if ($null -eq $value) {
            continue
        }

        foreach ($part in ($value.ToString() -split ',')) {
            $trimmed = $part.Trim()
            if (-not [string]::IsNullOrWhiteSpace($trimmed)) {
                $list.Add($trimmed)
            }
        }
    }

    return @($list)
}

function Get-RelativePath {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$FullPath
    )

    $rootPath = Normalize-Path -Path $Root
    if (-not $rootPath.EndsWith([System.IO.Path]::DirectorySeparatorChar)) {
        $rootPath += [System.IO.Path]::DirectorySeparatorChar
    }

    $targetPath = Normalize-Path -Path $FullPath
    if ($targetPath.StartsWith($rootPath, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $targetPath.Substring($rootPath.Length)
    }

    return [System.IO.Path]::GetFileName($targetPath)
}

function Get-TreePath {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$FullPath
    )

    return Get-RelativePath -Root $Root -FullPath $FullPath
}

function Test-IgnoredFolder {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string[]]$Ignored
    )

    return $Ignored -contains $Name
}

function Test-IgnoredFile {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string[]]$Ignored
    )

    return $Ignored -contains $Name
}

function Test-PathInsideRoot {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$Candidate
    )

    $rootPath = Normalize-Path -Path $Root
    if (-not $rootPath.EndsWith([System.IO.Path]::DirectorySeparatorChar)) {
        $rootPath += [System.IO.Path]::DirectorySeparatorChar
    }

    $candidatePath = Normalize-Path -Path $Candidate
    return $candidatePath.StartsWith($rootPath, [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-FileEntries {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string[]]$Allowed,
        [Parameter(Mandatory = $true)][string[]]$IgnoredFolders,
        [Parameter(Mandatory = $true)][string[]]$IgnoredFiles,
        [Parameter(Mandatory = $true)][string]$ExcludedRoot,
        [Parameter(Mandatory = $true)][long]$MaxSizeBytes
    )

    $allowedSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($ext in $Allowed) {
        [void]$allowedSet.Add((Normalize-Extension -Extension $ext))
    }

    $results = [System.Collections.Generic.List[object]]::new()

    function Recurse-Directory {
        param([Parameter(Mandatory = $true)][string]$Path)

        $children = Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue
        foreach ($child in $children) {
            if ($child.PSIsContainer) {
                if (Test-IgnoredFolder -Name $child.Name -Ignored $IgnoredFolders) {
                    continue
                }

                if (-not [string]::IsNullOrWhiteSpace($ExcludedRoot)) {
                    $normalizedChild = Normalize-Path -Path $child.FullName
                    $normalizedExcluded = Normalize-Path -Path $ExcludedRoot
                    if ($normalizedChild.Equals($normalizedExcluded, [System.StringComparison]::OrdinalIgnoreCase)) {
                        continue
                    }
                }

                Recurse-Directory -Path $child.FullName
                continue
            }

            if (Test-IgnoredFile -Name $child.Name -Ignored $IgnoredFiles) {
                continue
            }

            if ($child.Length -gt $MaxSizeBytes) {
                continue
            }

            $extension = Normalize-Extension -Extension $child.Extension
            if (-not $allowedSet.Contains($extension)) {
                continue
            }

            $content = Get-Content -LiteralPath $child.FullName -Raw -ErrorAction Stop
            $treePath = Get-TreePath -Root $Root -FullPath $child.FullName

            $entry = [pscustomobject]@{
                FullPath    = $child.FullName
                TreePath    = $treePath
                Name        = $child.Name
                Extension   = $extension
                SizeBytes   = [int64]$child.Length
                Content     = $content
                EntryLength = 0
            }

            $entry | Add-Member -NotePropertyName EntryLength -NotePropertyValue (Get-EntryText -Entry $entry).Length -Force
            $results.Add($entry)
        }
    }

    Recurse-Directory -Path $Root
    return $results
}

function Get-EntryText {
    param([Parameter(Mandatory = $true)]$Entry)

    $builder = [System.Text.StringBuilder]::new()
    [void]$builder.AppendLine('===== FILE START =====')
    [void]$builder.AppendLine("Path: $($Entry.FullPath)")
    [void]$builder.AppendLine("TreePath: $($Entry.TreePath)")
    [void]$builder.AppendLine("Name: $($Entry.Name)")
    [void]$builder.AppendLine("Extension: $($Entry.Extension)")
    [void]$builder.AppendLine("SizeBytes: $($Entry.SizeBytes)")
    [void]$builder.AppendLine("ContentChars: $($Entry.Content.Length)")
    [void]$builder.AppendLine('----------------------')
    [void]$builder.AppendLine($Entry.Content)
    [void]$builder.AppendLine('======================')
    [void]$builder.AppendLine("===== EOF: $($Entry.FullPath) =====")
    return $builder.ToString()
}

function New-Chunk {
    return [pscustomobject]@{
        Entries = [System.Collections.Generic.List[object]]::new()
        Length  = 0
    }
}

function Add-EntryToChunks {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        [Parameter(Mandatory = $true)][System.Collections.Generic.List[object]]$Chunks,
        [Parameter(Mandatory = $true)][int]$Limit
    )

    $entryText = Get-EntryText -Entry $Entry
    $entryLength = $entryText.Length
    $Entry | Add-Member -NotePropertyName EntryText -NotePropertyValue $entryText -Force
    $Entry | Add-Member -NotePropertyName EntryLength -NotePropertyValue $entryLength -Force

    foreach ($chunk in $Chunks) {
        if (($chunk.Length + $entryLength) -le $Limit) {
            [void]$chunk.Entries.Add($Entry)
            $chunk.Length += $entryLength
            return
        }
    }

    $newChunk = New-Chunk
    [void]$newChunk.Entries.Add($Entry)
    $newChunk.Length = $entryLength
    $Chunks.Add($newChunk) | Out-Null
}

function Write-ChunkFile {
    param(
        [Parameter(Mandatory = $true)][string]$DestinationFolder,
        [Parameter(Mandatory = $true)][string]$ExtensionGroup,
        [Parameter(Mandatory = $true)][int]$Index,
        [Parameter(Mandatory = $true)]$Chunk,
        [Parameter(Mandatory = $true)][string]$Root
    )

    if (-not (Test-Path -LiteralPath $DestinationFolder)) {
        New-Item -ItemType Directory -Path $DestinationFolder -Force | Out-Null
    }

    $fileName = '{0}_{1:000}.txt' -f $ExtensionGroup.TrimStart('.'), $Index
    $outputPath = Join-Path -Path $DestinationFolder -ChildPath $fileName

    $writer = [System.Text.StringBuilder]::new()
    [void]$writer.AppendLine('===== CONCATENATED OUTPUT =====')
    [void]$writer.AppendLine("Root: $Root")
    [void]$writer.AppendLine("ExtensionGroup: $ExtensionGroup")
    [void]$writer.AppendLine("Chunk: $Index")
    [void]$writer.AppendLine("SourceFiles: $($Chunk.Entries.Count)")
    [void]$writer.AppendLine("Generated: $(Get-Date -Format o)")
    [void]$writer.AppendLine('==============================')
    [void]$writer.AppendLine()

    foreach ($entry in $Chunk.Entries) {
        [void]$writer.Append($entry.EntryText)
        if (-not $writer.ToString().EndsWith([Environment]::NewLine)) {
            [void]$writer.AppendLine()
        }
        [void]$writer.AppendLine()
    }

    [System.IO.File]::WriteAllText($outputPath, $writer.ToString(), [System.Text.Encoding]::UTF8)
    return $outputPath
}

$InputFolder = Normalize-Path -Path $InputFolder
if (-not (Test-Path -LiteralPath $InputFolder -PathType Container)) {
    throw "Input folder not found: $InputFolder"
}

$OutputFolder = Normalize-Path -Path $OutputFolder
if (-not (Test-Path -LiteralPath $OutputFolder)) {
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

$normalizedAllowed = @(Split-ListParameter -Values $AllowedExtensions | ForEach-Object { Normalize-Extension -Extension $_ })
$normalizedIgnoredFolders = @(Split-ListParameter -Values $IgnoredFolders)
$normalizedIgnoredFiles = @(Split-ListParameter -Values $IgnoredFiles)

$excludedRoot = ''
if ($SkipOutputFolderWhenInsideInput -and (Test-PathInsideRoot -Root $InputFolder -Candidate $OutputFolder)) {
    $excludedRoot = $OutputFolder
}

$entries = Get-FileEntries -Root $InputFolder -Allowed $normalizedAllowed -IgnoredFolders $normalizedIgnoredFolders -IgnoredFiles $normalizedIgnoredFiles -ExcludedRoot $excludedRoot -MaxSizeBytes $MaxIndividualFileSizeBytes
if ($entries.Count -eq 0) {
    Write-Host "No matching files were found in $InputFolder."
    return
}

$groups = $entries | Group-Object Extension | Sort-Object Name
$generatedFiles = [System.Collections.Generic.List[string]]::new()

foreach ($group in $groups) {
    $extensionGroup = if ([string]::IsNullOrWhiteSpace($group.Name)) { '.unknown' } else { $group.Name }
    $groupFolder = Join-Path -Path $OutputFolder -ChildPath $extensionGroup.TrimStart('.')

    $sortedEntries = $group.Group | Sort-Object @{ Expression = { $_.EntryText.Length }; Descending = $true }, @{ Expression = { $_.FullPath }; Descending = $false }

    $chunks = [System.Collections.Generic.List[object]]::new()
    foreach ($entry in $sortedEntries) {
        Add-EntryToChunks -Entry $entry -Chunks $chunks -Limit $GeneratedFileCharLimit
    }

    for ($i = 0; $i -lt $chunks.Count; $i++) {
        $path = Write-ChunkFile -DestinationFolder $groupFolder -ExtensionGroup $extensionGroup -Index ($i + 1) -Chunk $chunks[$i] -Root $InputFolder
        $generatedFiles.Add($path) | Out-Null
    }
}

$generatedFiles | ForEach-Object { Write-Host $_ }
Write-Host "Generated $($generatedFiles.Count) file(s)."
