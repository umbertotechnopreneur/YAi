[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$api_key,

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$action = 'run',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$output_folder = (Join-Path -Path (Get-Location) -ChildPath 'metals-dev-output'),

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$currency_base = 'USD',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$metal_unit = 'toz',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$fx_pairs = 'EUR/USD,USD/VND,EUR/VND',

    [Parameter()]
    [ValidateRange(5, 300)]
    [int]$timeout_seconds = 30,

    [Parameter()]
    [bool]$append_history = $true,

    [Parameter()]
    [string]$from_code,

    [Parameter()]
    [string]$to_code,

    [Parameter()]
    [decimal]$amount = 1,

    [Parameter()]
    [string]$currency = 'USD',

    [Parameter()]
    [string]$unit = 'toz',

    [Parameter()]
    [bool]$include_currencies = $true,

    [Parameter()]
    [bool]$include_metals = $true,

    [Parameter()]
    [bool]$include_units = $true
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$SupportedMetals = [ordered]@{
    gold = 'Spot Gold'
    silver = 'Spot Silver'
    platinum = 'Spot Platinum'
    palladium = 'Spot Palladium'
    lbma_gold_am = 'LBMA Gold AM'
    lbma_gold_pm = 'LBMA Gold PM'
    lbma_silver = 'LBMA Silver'
    lbma_platinum_am = 'LBMA Platinum AM'
    lbma_platinum_pm = 'LBMA Platinum PM'
    lbma_palladium_am = 'LBMA Palladium AM'
    lbma_palladium_pm = 'LBMA Palladium PM'
    mcx_gold = 'MCX Gold Futures'
    mcx_gold_am = 'MCX Spot Gold AM'
    mcx_gold_pm = 'MCX Spot Gold PM'
    mcx_silver = 'MCX Silver Futures'
    mcx_silver_am = 'MCX Spot Silver AM'
    mcx_silver_pm = 'MCX Spot Silver PM'
    ibja_gold = 'IBJA Gold'
    aluminum = 'Spot Aluminum'
    copper = 'Spot Copper'
    lead = 'Spot Lead'
    nickel = 'Spot Nickel'
    zinc = 'Spot Zinc'
    lme_aluminum = 'LME Aluminum 3M'
    lme_copper = 'LME Copper 3M'
    lme_lead = 'LME Lead 3M'
    lme_nickel = 'LME Nickel 3M'
    lme_zinc = 'LME Zinc 3M'
}

$SupportedUnits = [ordered]@{
    toz = 'Troy Ounce'
    mt  = 'Metric Tonne'
    kg  = 'Kilogram'
    g   = 'Gram'
}

function Get-NormalizedOutputFolder {
    param([Parameter(Mandatory = $true)][string]$Path)

    $resolved = [System.IO.Path]::GetFullPath($Path)
    if (-not (Test-Path -LiteralPath $resolved)) {
        New-Item -ItemType Directory -Path $resolved -Force | Out-Null
    }

    return $resolved
}

function Invoke-MetalsDevJson {
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][int]$TimeoutSeconds
    )

    try {
        return Invoke-RestMethod -Method Get -Uri $Url -Headers @{ 'Accept' = 'application/json' } -TimeoutSec $TimeoutSeconds
    }
    catch {
        Write-Error "HTTP request failed for URL '$Url'. $($_.Exception.Message)"
        exit 1
    }
}

function Assert-SuccessStatus {
    param(
        [Parameter(Mandatory = $true)]$Response,
        [Parameter(Mandatory = $true)][string]$EndpointName
    )

    if ($null -eq $Response) {
        Write-Error "Empty response from endpoint '$EndpointName'."
        exit 1
    }

    if ($Response.status -ne 'success') {
        $errorCode = if ($null -ne $Response.error_code) { $Response.error_code } else { 'unknown' }
        $errorMessage = if ($null -ne $Response.error_message) { $Response.error_message } else { 'Unknown API error.' }
        Write-Error "Metals.Dev returned failure for '$EndpointName'. Code: $errorCode. Message: $errorMessage"
        exit 1
    }
}

function Get-RequiredProperty {
    param(
        [Parameter(Mandatory = $true)]$Object,
        [Parameter(Mandatory = $true)][string]$Name
    )

    $prop = $Object.PSObject.Properties[$Name]
    if ($null -eq $prop) {
        Write-Error "Required property '$Name' was not found in API response."
        exit 1
    }

    return $prop.Value
}

function Get-FxValue {
    param(
        [Parameter(Mandatory = $true)]$Currencies,
        [Parameter(Mandatory = $true)][string]$Code
    )

    $normalizedCode = $Code.Trim().ToUpperInvariant()
    $prop = $Currencies.PSObject.Properties[$normalizedCode]
    if ($null -eq $prop) {
        Write-Error "Currency '$normalizedCode' was not found in Metals.Dev currencies response."
        exit 1
    }

    return [decimal]$prop.Value
}

function Get-MetalValue {
    param(
        [Parameter(Mandatory = $true)]$Metals,
        [Parameter(Mandatory = $true)][string]$Code
    )

    $normalizedCode = $Code.Trim().ToLowerInvariant()
    $prop = $Metals.PSObject.Properties[$normalizedCode]
    if ($null -eq $prop) {
        Write-Error "Metal '$normalizedCode' was not found in Metals.Dev latest response."
        exit 1
    }

    return [decimal]$prop.Value
}

function Convert-UsdBasePairs {
    param(
        [Parameter(Mandatory = $true)]$Currencies,
        [Parameter(Mandatory = $true)][string[]]$RequestedPairs
    )

    $rows = [System.Collections.Generic.List[object]]::new()

    foreach ($pair in $RequestedPairs) {
        $trimmed = $pair.Trim().ToUpperInvariant()
        if ([string]::IsNullOrWhiteSpace($trimmed)) {
            continue
        }

        if ($trimmed -notmatch '^[A-Z]{3}/[A-Z]{3}$') {
            Write-Error "Invalid FX pair format '$trimmed'. Expected format: EUR/USD"
            exit 1
        }

        $parts = $trimmed.Split('/')
        $baseCode = $parts[0]
        $quoteCode = $parts[1]

        $baseRate = Get-FxValue -Currencies $Currencies -Code $baseCode
        $quoteRate = Get-FxValue -Currencies $Currencies -Code $quoteCode

        if ($baseRate -eq 0) {
            Write-Error "Base rate for '$baseCode' is zero. Cannot derive FX pair '$trimmed'."
            exit 1
        }

        $pairRate = [decimal]($quoteRate / $baseRate)

        $rows.Add([pscustomobject]@{
            Pair      = $trimmed
            Base      = $baseCode
            Quote     = $quoteCode
            Rate      = [decimal]::Round($pairRate, 6)
            BaseRate  = [decimal]::Round($baseRate, 6)
            QuoteRate = [decimal]::Round($quoteRate, 6)
        })
    }

    return $rows
}

function Import-CsvSafe {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return @()
    }

    try {
        return Import-Csv -LiteralPath $Path
    }
    catch {
        Write-Error "Failed to read CSV '$Path'. $($_.Exception.Message)"
        exit 1
    }
}

function Get-PreviousByKey {
    param(
        [Parameter(Mandatory = $true)]$Rows,
        [Parameter(Mandatory = $true)][string]$KeyProperty,
        [Parameter(Mandatory = $true)][string]$KeyValue
    )

    $matches = @($Rows | Where-Object { $_.$KeyProperty -eq $KeyValue })
    if ($matches.Count -eq 0) {
        return $null
    }

    return $matches[-1]
}

function Get-DeltaInfo {
    param(
        [Parameter(Mandatory = $false)]$PreviousValue,
        [Parameter(Mandatory = $true)][decimal]$CurrentValue
    )

    if ($null -eq $PreviousValue -or [string]::IsNullOrWhiteSpace([string]$PreviousValue)) {
        return [pscustomobject]@{
            Delta        = $null
            DeltaPercent = $null
            Label        = 'n/a'
        }
    }

    $prev = [decimal]$PreviousValue
    $delta = $CurrentValue - $prev
    $deltaPercent = if ($prev -ne 0) { ($delta / $prev) * 100m } else { $null }

    $label = if ($delta -gt 0) {
        "+{0:N4}" -f $delta
    }
    elseif ($delta -lt 0) {
        "{0:N4}" -f $delta
    }
    else {
        "0.0000"
    }

    return [pscustomobject]@{
        Delta        = [decimal]::Round($delta, 6)
        DeltaPercent = if ($null -ne $deltaPercent) { [decimal]::Round($deltaPercent, 6) } else { $null }
        Label        = $label
    }
}

function Get-LatestResponse {
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][string]$Currency,
        [Parameter(Mandatory = $true)][string]$Unit,
        [Parameter(Mandatory = $true)][int]$TimeoutSeconds
    )

    $latestUrl = "https://api.metals.dev/v1/latest?api_key=$([uri]::EscapeDataString($ApiKey))&currency=$([uri]::EscapeDataString($Currency))&unit=$([uri]::EscapeDataString($Unit))"
    $latestResponse = Invoke-MetalsDevJson -Url $latestUrl -TimeoutSeconds $TimeoutSeconds
    Assert-SuccessStatus -Response $latestResponse -EndpointName 'latest'
    return $latestResponse
}

function Get-CurrenciesResponse {
    param(
        [Parameter(Mandatory = $true)][string]$ApiKey,
        [Parameter(Mandatory = $true)][int]$TimeoutSeconds
    )

    $currenciesUrl = "https://api.metals.dev/v1/currencies?api_key=$([uri]::EscapeDataString($ApiKey))"
    $currenciesResponse = Invoke-MetalsDevJson -Url $currenciesUrl -TimeoutSeconds $TimeoutSeconds
    Assert-SuccessStatus -Response $currenciesResponse -EndpointName 'currencies'
    return $currenciesResponse
}

function Resolve-CodeType {
    param(
        [Parameter(Mandatory = $true)][string]$Code,
        [Parameter(Mandatory = $true)]$Currencies,
        [Parameter(Mandatory = $true)]$Metals
    )

    $trimmed = $Code.Trim()
    if ([string]::IsNullOrWhiteSpace($trimmed)) {
        Write-Error 'Code cannot be empty.'
        exit 1
    }

    $upper = $trimmed.ToUpperInvariant()
    if ($null -ne $Currencies.PSObject.Properties[$upper]) {
        return [pscustomobject]@{ Type = 'currency'; Normalized = $upper }
    }

    $lower = $trimmed.ToLowerInvariant()
    if ($null -ne $Metals.PSObject.Properties[$lower]) {
        return [pscustomobject]@{ Type = 'metal'; Normalized = $lower }
    }

    Write-Error "Unsupported code '$Code'. Use list_symbols to see available currencies and metals."
    exit 1
}

function Convert-Amount {
    param(
        [Parameter(Mandatory = $true)][string]$FromCode,
        [Parameter(Mandatory = $true)][string]$ToCode,
        [Parameter(Mandatory = $true)][decimal]$Amount,
        [Parameter(Mandatory = $true)]$Currencies,
        [Parameter(Mandatory = $true)]$Metals,
        [Parameter(Mandatory = $true)][string]$Currency,
        [Parameter(Mandatory = $true)][string]$Unit,
        [Parameter(Mandatory = $true)][string]$Timestamp
    )

    $fromInfo = Resolve-CodeType -Code $FromCode -Currencies $Currencies -Metals $Metals
    $toInfo = Resolve-CodeType -Code $ToCode -Currencies $Currencies -Metals $Metals

    $fromValueInQuote = if ($fromInfo.Type -eq 'currency') {
        Get-FxValue -Currencies $Currencies -Code $fromInfo.Normalized
    } else {
        Get-MetalValue -Metals $Metals -Code $fromInfo.Normalized
    }

    $toValueInQuote = if ($toInfo.Type -eq 'currency') {
        Get-FxValue -Currencies $Currencies -Code $toInfo.Normalized
    } else {
        Get-MetalValue -Metals $Metals -Code $toInfo.Normalized
    }

    if ($toValueInQuote -eq 0) {
        Write-Error "Target value for '$ToCode' is zero. Conversion cannot be computed."
        exit 1
    }

    $converted = ($Amount * $fromValueInQuote) / $toValueInQuote
    $effectiveRate = $fromValueInQuote / $toValueInQuote

    return [pscustomobject]@{
        FromCode       = $fromInfo.Normalized
        FromType       = $fromInfo.Type
        ToCode         = $toInfo.Normalized
        ToType         = $toInfo.Type
        Amount         = [decimal]::Round($Amount, 8)
        Rate           = [decimal]::Round($effectiveRate, 8)
        Converted      = [decimal]::Round($converted, 8)
        QuoteCurrency  = $Currency.ToUpperInvariant()
        Unit           = $Unit
        Timestamp      = $Timestamp
        FromValueQuote = [decimal]::Round($fromValueInQuote, 8)
        ToValueQuote   = [decimal]::Round($toValueInQuote, 8)
    }
}

function Write-RunReport {
    param(
        [Parameter(Mandatory = $true)][string]$OutputRoot,
        [Parameter(Mandatory = $true)][string]$CurrencyBase,
        [Parameter(Mandatory = $true)][string]$MetalUnit,
        [Parameter(Mandatory = $true)]$TimestampUtc,
        [Parameter(Mandatory = $true)][decimal]$Gold,
        [Parameter(Mandatory = $true)][decimal]$Silver,
        [Parameter(Mandatory = $true)]$GoldDelta,
        [Parameter(Mandatory = $true)]$SilverDelta,
        [Parameter(Mandatory = $true)]$FxRows,
        [Parameter(Mandatory = $true)]$FxDeltaRows,
        [Parameter(Mandatory = $true)]$LatestResponse,
        [Parameter(Mandatory = $true)][bool]$AppendHistory
    )

    $reportPath = Join-Path -Path $OutputRoot -ChildPath 'latest-report.md'
    $snapshotPath = Join-Path -Path $OutputRoot -ChildPath 'latest-snapshot.json'
    $metalsCsvPath = Join-Path -Path $OutputRoot -ChildPath 'history-metals.csv'
    $fxCsvPath = Join-Path -Path $OutputRoot -ChildPath 'history-fx.csv'

    $reportLines = [System.Collections.Generic.List[string]]::new()
    $reportLines.Add('# Metals.Dev Snapshot') | Out-Null
    $reportLines.Add('') | Out-Null
    $reportLines.Add("- Timestamp (UTC): $($TimestampUtc.ToString('u'))") | Out-Null
    $reportLines.Add("- Currency Base: $CurrencyBase") | Out-Null
    $reportLines.Add("- Metal Unit: $MetalUnit") | Out-Null
    $reportLines.Add('') | Out-Null
    $reportLines.Add('## Metals') | Out-Null
    $reportLines.Add('') | Out-Null
    $reportLines.Add('| Metal | Value | Delta | Delta % |') | Out-Null
    $reportLines.Add('|---|---:|---:|---:|') | Out-Null
    $reportLines.Add(("| Gold | {0:N6} | {1} | {2} |" -f $Gold, $GoldDelta.Label, $(if ($null -ne $GoldDelta.DeltaPercent) { '{0:N4}%' -f $GoldDelta.DeltaPercent } else { 'n/a' }))) | Out-Null
    $reportLines.Add(("| Silver | {0:N6} | {1} | {2} |" -f $Silver, $SilverDelta.Label, $(if ($null -ne $SilverDelta.DeltaPercent) { '{0:N4}%' -f $SilverDelta.DeltaPercent } else { 'n/a' }))) | Out-Null
    $reportLines.Add('') | Out-Null
    $reportLines.Add('## FX Pairs') | Out-Null
    $reportLines.Add('') | Out-Null
    $reportLines.Add('| Pair | Rate | Delta | Delta % |') | Out-Null
    $reportLines.Add('|---|---:|---:|---:|') | Out-Null

    foreach ($fxRow in $FxRows) {
        $fxDelta = $FxDeltaRows[$fxRow.Pair]
        $deltaLabel = if ($null -ne $fxDelta) { $fxDelta.Label } else { 'n/a' }
        $deltaPct = if ($null -ne $fxDelta -and $null -ne $fxDelta.DeltaPercent) { '{0:N4}%' -f $fxDelta.DeltaPercent } else { 'n/a' }
        $reportLines.Add(("| {0} | {1:N6} | {2} | {3} |" -f $fxRow.Pair, $fxRow.Rate, $deltaLabel, $deltaPct)) | Out-Null
    }

    $reportLines.Add('') | Out-Null
    [System.IO.File]::WriteAllText($reportPath, ($reportLines -join [Environment]::NewLine), [System.Text.Encoding]::UTF8)

    $snapshot = [pscustomobject]@{
        timestamp_utc = $TimestampUtc.ToString('o')
        currency_base = $CurrencyBase
        metal_unit = $MetalUnit
        metals = [pscustomobject]@{
            gold = $Gold
            silver = $Silver
        }
        fx_pairs = $FxRows
        raw_latest = $LatestResponse
    }

    [System.IO.File]::WriteAllText($snapshotPath, ($snapshot | ConvertTo-Json -Depth 8), [System.Text.Encoding]::UTF8)

    if ($AppendHistory) {
        $metalRows = @(
            [pscustomobject]@{ TimestampUtc = $TimestampUtc.ToString('o'); Metal = 'gold'; Currency = $CurrencyBase; Unit = $MetalUnit; Value = [decimal]::Round($Gold, 8) },
            [pscustomobject]@{ TimestampUtc = $TimestampUtc.ToString('o'); Metal = 'silver'; Currency = $CurrencyBase; Unit = $MetalUnit; Value = [decimal]::Round($Silver, 8) }
        )

        foreach ($metalRow in $metalRows) {
            $line = ($metalRow | ConvertTo-Csv -NoTypeInformation)[1]
            if (-not (Test-Path -LiteralPath $metalsCsvPath)) {
                ($metalRow | Export-Csv -LiteralPath $metalsCsvPath -NoTypeInformation -Encoding UTF8)
            } else {
                Add-Content -LiteralPath $metalsCsvPath -Value $line -Encoding UTF8
            }
        }

        foreach ($fxRow in $FxRows) {
            $csvRow = [pscustomobject]@{
                TimestampUtc = $TimestampUtc.ToString('o')
                Pair = $fxRow.Pair
                Base = $fxRow.Base
                Quote = $fxRow.Quote
                Rate = [decimal]::Round($fxRow.Rate, 8)
            }
            $line = ($csvRow | ConvertTo-Csv -NoTypeInformation)[1]
            if (-not (Test-Path -LiteralPath $fxCsvPath)) {
                ($csvRow | Export-Csv -LiteralPath $fxCsvPath -NoTypeInformation -Encoding UTF8)
            } else {
                Add-Content -LiteralPath $fxCsvPath -Value $line -Encoding UTF8
            }
        }
    }

    Write-Output "Report written: $reportPath"
    Write-Output "Snapshot written: $snapshotPath"
    if ($AppendHistory) {
        Write-Output "History updated: $metalsCsvPath"
        Write-Output "History updated: $fxCsvPath"
    }
}

function Invoke-RunAction {
    $outputRoot = Get-NormalizedOutputFolder -Path $output_folder
    $latestResponse = Get-LatestResponse -ApiKey $api_key -Currency $currency_base -Unit $metal_unit -TimeoutSeconds $timeout_seconds
    $currenciesResponse = Get-CurrenciesResponse -ApiKey $api_key -TimeoutSeconds $timeout_seconds

    $metals = Get-RequiredProperty -Object $latestResponse -Name 'metals'
    $currencies = Get-RequiredProperty -Object $currenciesResponse -Name 'currencies'

    $gold = [decimal](Get-RequiredProperty -Object $metals -Name 'gold')
    $silver = [decimal](Get-RequiredProperty -Object $metals -Name 'silver')
    $timestampRaw = if ($null -ne $latestResponse.timestamp) { [string]$latestResponse.timestamp } else { (Get-Date).ToString('o') }
    $timestampUtc = [DateTimeOffset]::Parse($timestampRaw).ToUniversalTime()

    $pairList = @($fx_pairs.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $fxRows = Convert-UsdBasePairs -Currencies $currencies -RequestedPairs $pairList

    $metalsCsvPath = Join-Path -Path $outputRoot -ChildPath 'history-metals.csv'
    $fxCsvPath = Join-Path -Path $outputRoot -ChildPath 'history-fx.csv'
    $existingMetals = Import-CsvSafe -Path $metalsCsvPath
    $existingFx = Import-CsvSafe -Path $fxCsvPath

    $goldPrev = Get-PreviousByKey -Rows $existingMetals -KeyProperty 'Metal' -KeyValue 'gold'
    $silverPrev = Get-PreviousByKey -Rows $existingMetals -KeyProperty 'Metal' -KeyValue 'silver'
    $goldDelta = Get-DeltaInfo -PreviousValue $goldPrev.Value -CurrentValue $gold
    $silverDelta = Get-DeltaInfo -PreviousValue $silverPrev.Value -CurrentValue $silver

    $fxDeltaRows = @{}
    foreach ($fxRow in $fxRows) {
        $prevFx = Get-PreviousByKey -Rows $existingFx -KeyProperty 'Pair' -KeyValue $fxRow.Pair
        $fxDeltaRows[$fxRow.Pair] = Get-DeltaInfo -PreviousValue $prevFx.Rate -CurrentValue ([decimal]$fxRow.Rate)
    }

    Write-RunReport -OutputRoot $outputRoot -CurrencyBase $currency_base -MetalUnit $metal_unit -TimestampUtc $timestampUtc -Gold $gold -Silver $silver -GoldDelta $goldDelta -SilverDelta $silverDelta -FxRows $fxRows -FxDeltaRows $fxDeltaRows -LatestResponse $latestResponse -AppendHistory $append_history
}

function Invoke-ConvertAction {
    if ([string]::IsNullOrWhiteSpace($from_code)) {
        Write-Error "Parameter 'from_code' is required for action=convert."
        exit 1
    }
    if ([string]::IsNullOrWhiteSpace($to_code)) {
        Write-Error "Parameter 'to_code' is required for action=convert."
        exit 1
    }

    $latestResponse = Get-LatestResponse -ApiKey $api_key -Currency $currency -Unit $unit -TimeoutSeconds $timeout_seconds
    $currenciesResponse = Get-CurrenciesResponse -ApiKey $api_key -TimeoutSeconds $timeout_seconds

    $metals = Get-RequiredProperty -Object $latestResponse -Name 'metals'
    $currencies = Get-RequiredProperty -Object $currenciesResponse -Name 'currencies'
    $timestampRaw = if ($null -ne $latestResponse.timestamp) { [string]$latestResponse.timestamp } else { (Get-Date).ToString('o') }

    $result = Convert-Amount -FromCode $from_code -ToCode $to_code -Amount $amount -Currencies $currencies -Metals $metals -Currency $currency -Unit $unit -Timestamp $timestampRaw

    Write-Output "Conversion Result"
    Write-Output "Timestamp: $($result.Timestamp)"
    Write-Output "Context Currency: $($result.QuoteCurrency)"
    Write-Output "Unit: $($result.Unit)"
    Write-Output "From: $($result.Amount) $($result.FromCode) [$($result.FromType)]"
    Write-Output "To: $($result.Converted) $($result.ToCode) [$($result.ToType)]"
    Write-Output "Effective Rate: 1 $($result.FromCode) = $($result.Rate) $($result.ToCode)"
}

function Invoke-ListSymbolsAction {
    $currencyList = @{}
    if ($include_currencies) {
        $currenciesResponse = Get-CurrenciesResponse -ApiKey $api_key -TimeoutSeconds $timeout_seconds
        $currencies = Get-RequiredProperty -Object $currenciesResponse -Name 'currencies'
        foreach ($prop in $currencies.PSObject.Properties | Sort-Object Name) {
            $currencyList[$prop.Name] = $prop.Value
        }
    }

    if ($include_metals) {
        Write-Output 'Supported Metals'
        foreach ($entry in $SupportedMetals.GetEnumerator()) {
            Write-Output ("- {0} : {1}" -f $entry.Key, $entry.Value)
        }
        Write-Output ''
    }

    if ($include_units) {
        Write-Output 'Supported Units'
        foreach ($entry in $SupportedUnits.GetEnumerator()) {
            Write-Output ("- {0} : {1}" -f $entry.Key, $entry.Value)
        }
        Write-Output ''
    }

    if ($include_currencies) {
        Write-Output 'Supported Currencies'
        foreach ($code in ($currencyList.Keys | Sort-Object)) {
            Write-Output ("- {0}" -f $code)
        }
    }
}

switch ($action.ToLowerInvariant()) {
    'run' { Invoke-RunAction }
    'convert' { Invoke-ConvertAction }
    'list_symbols' { Invoke-ListSymbolsAction }
    default {
        Write-Error "Unsupported action '$action'. Supported actions: run, convert, list_symbols."
        exit 1
    }
}
